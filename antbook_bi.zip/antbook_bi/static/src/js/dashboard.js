odoo.define('antbook_bi.dashboard', function (require) {
    "use strict";

    console.log("Antbook Dashboard Loaded");
});
